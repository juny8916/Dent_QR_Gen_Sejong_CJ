"""Placeholder module; package entry point lives in __init__.py."""
